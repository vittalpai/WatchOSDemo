//
//  InterfaceController.swift
//  WatchDemoApp WatchKit Extension
//
//  Created by Amichai Meir on 12/01/2016.
//  Copyright © 2016 IBM. All rights reserved.
//

import WatchKit
import Foundation

class InterfaceController: WKInterfaceController {
    
    var isRemoteDisabled = false
    var pinCodeScreenShouldBeDisplayed = false
    
    @IBOutlet var activityIndicatorImage: WKInterfaceImage!
    
    func showActivityIndicator() {
        activityIndicatorImage.setHidden(false)
        activityIndicatorImage.startAnimating()
    }
    
    func hideActivityIndicator() {
        self.activityIndicatorImage.stopAnimating()
        self.activityIndicatorImage.setHidden(true)
    }
    
    override func awake(withContext context: Any?)  {
        super.awake(withContext: context)
    
        activityIndicatorImage.setHidden(true)
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func balance() {
       
        self.showActivityIndicator()
        //sleep(5)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // Change `2.0` to the desired number of var var title = "Balance";
            
        let title = "Mod Resorts";
        let message = "Your Booking ID 92138XZA for BLR TO SFO on 9th Mar 2020 is confirmed.\n\n  Check-in Timings : 9:00 AM IST"
        let act : WKAlertAction = WKAlertAction(title: "OK", style: WKAlertActionStyle.default, handler: { () -> Void in
                       
                   })
                   let actions : [WKAlertAction] = [act];
                   
                   self.hideActivityIndicator()
                   
                   //If remote disabled, we showed error message already in MyRemoteDisableChallengeHandler
                   if (!self.isRemoteDisabled) {
                       self.presentAlert(withTitle: title, message: message, preferredStyle: WKAlertControllerStyle.alert, actions: actions)
                   }
                   else {
                       self.isRemoteDisabled = false;
                   }
        }
        
        
    }
    
}
