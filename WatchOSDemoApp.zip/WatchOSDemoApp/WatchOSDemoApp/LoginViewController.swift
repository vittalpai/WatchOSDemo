//
//  LoginViewController.swift
//  MFPWatchDemoApp
//
//  Created by Amichai Meir on 17/01/2016.
//  Copyright © 2016 IBM. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController : UIViewController {
    
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var errorMsg: UILabel!
    
    var firstTime : Bool = true
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if (firstTime) {
            self.errorMsg.isHidden = true
        }
        else {
            self.errorMsg.isHidden = false
        }
    }
    
    @IBAction func login(sender: AnyObject) {
     //   self.vc.navigationController.popViewController(animated: true)
    }
    
    
}
