//
//  ViewController.swift
//  MFPWatchDemoApp
//
//  Created by Amichai Meir on 17/01/2016.
//  Copyright © 2016 IBM. All rights reserved.
//

import UIKit
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

        
    @IBAction func balance(sender: AnyObject) {
            
            //self.hideActivityIndicator()
            
            let adapterResponseAlert : UIAlertController = UIAlertController(title: title, message: "success", preferredStyle: UIAlertControllerStyle.alert)
            let ok : UIAlertAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                adapterResponseAlert.dismiss(animated: true, completion: nil)
            })
            adapterResponseAlert.addAction(ok)
            
            self.present(adapterResponseAlert, animated: true, completion: nil)

    }
    
}

